# Road to MVC — دستور دقیق Copy و Paste

این سند بر اساس نسخه فعلی پروژه در تاریخ 2026-08-27 نوشته شده است. قالب تمام مراحل فقط این است:

> از `فایل مبدأ:خط شروع-خط پایان` کپی کن → داخل `فایل مقصد` → دقیقاً بعد از تابع مشخص‌شده Paste کن.

شماره‌خط مقصد نوشته نشده است، چون فایل مقصد با هر Paste تغییر می‌کند؛ محل Paste با نام تابع قبلی مشخص شده و ثابت می‌ماند.

## ساختار نهایی

```text
App/
├── Controllers/
│   ├── AuthController.php
│   ├── HomeController.php
│   ├── NotificationController.php
│   ├── ProfileController.php
│   ├── ReminderController.php
│   └── TaskController.php
├── Services/
│   ├── AuthService.php
│   ├── NotificationService.php
│   ├── ProfileService.php
│   ├── ReminderService.php
│   └── TaskService.php
├── Repositories/
│   ├── ReminderRepository.php
│   ├── TaskRepository.php
│   └── UserRepository.php
├── Models/
│   └── Reminder.php
├── Middleware/
│   ├── AuthMiddleware.php
│   └── CsrfMiddleware.php
├── Http/
│   ├── Request.php
│   ├── Response.php
│   └── Router.php
├── Helpers/
│   ├── AvatarHelper.php
│   └── TimezoneHelper.php
├── Notifications/
│   ├── NotificationSender.php
│   └── WebPushNotificationSender.php
└── Exceptions/
    └── SessionInitializationException.php
config/
├── app.php
└── database.php
routes/
├── api.php
└── web.php
views/
├── components/
│   ├── dashboard-header.php
│   ├── notification-formatters.php
│   ├── sidebar.php
│   ├── task-items.php
│   ├── task-modals.php
│   └── task-toolbar.php
├── layouts/
│   └── dashboard.php
├── modals/
│   ├── avatar-picker.php
│   ├── date-time.php
│   ├── notification-edit.php
│   ├── reminder.php
│   ├── repeat.php
│   └── task.php
└── pages/
    ├── account-settings.php
    ├── activity.php
    ├── auth.php
    ├── change-password.php
    ├── home.php
    ├── manage-tasks.php
    ├── messages.php
    ├── notifications.php
    └── profile.php
process/
│   └── send-reminders.php
public/
├── assets/
│   ├── css/
│   ├── img/
│   └── js/
└── index.php
storage/
└── avatars/
Database/
tests/
```

تا وقتی یک مرحله تست نشده، کد مبدأ را حذف نکن؛ ابتدا Copy کن، مقصد را اصلاح و تست کن، سپس مبدأ را پاک کن.

## وضعیت واقعی فایل‌های جدید در همین لحظه

کدهای جدول زیر را قبلاً کپی کرده‌ای. آن‌ها را دوباره از فایل Legacy کپی نکن:

| فایل جدید | چیزی که اکنون داخل آن وجود دارد | وضعیت |
| --- | --- | --- |
| `App/Controllers/AuthController.php:10-34` | Constructor و تابع `logout()` | کپی و کلاس‌بندی شده؛ بعداً با Middleware و Route هماهنگ می‌شود. |
| `App/Services/AuthService.php:7-31` | کلاس و تابع `logout()` | کامل کپی شده؛ دوباره `logoutUser()` را از `libs/lib-auth.php` کپی نکن. |
| `App/Http/Request.php:3-9` | تابع `isAjaxRequest()` | کپی شده؛ باید داخل namespace `App\Http` و کلاس `Request` قرار گیرد. |
| `App/Http/Response.php:7-34` | کلاس Response، Constructor، `redirect()` و `send()` | موجود است و باید نگه داشته شود. |
| `App/Http/Response.php:36-40` | تابع `diepage()` | قبلاً کپی شده، اما بیرون کلاس است؛ دوباره کپی نکن و طبق مرحله 2 آن را به متد داخل کلاس تبدیل کن. |
| `App/Helpers/TimezoneHelper.php:3-23` | دو تابع timezone | هر دو قبلاً کپی شده‌اند؛ دوباره از `libs/helpers.php` کپی نکن؛ به کلاس تبدیل شود. |
| `config/app.php:1-9` | آرایه تنظیمات اپلیکیشن | قبلاً انجام شده است؛ کامل است. |
| `config/database.php:1-16` | تنظیمات دیتابیس | قبلاً انجام شده است؛ کامل است. |
| `public/index.php:1-86` | لود تنظیمات، سشن امن و PDO | قبلاً انجام شده است؛ ساخت کانتینر، روتر و دیسپچ در مراحل بعدی اضافه می‌شود. |

عبارت «کپی کن» در ادامه سند فقط برای کدهایی است که هنوز در فایل مقصد وجود ندارند.

---

# مرحله 1 — Config و Bootstrap (انجام شده ✅)

## `config/app.php`

آرایه برگشتی شامل `title`, `base_path`, `base_url`, `timezone` پیاده‌سازی و تست شده است.

## `config/database.php`

آرایه برگشتی شامل `driver`, `host`, `port`, `database`, `username`, `password`, `charset`, `options` پیاده‌سازی و تست شده است.

## `public/index.php`

تنظیم Autoload، خواندن تنظیمات، راه‌اندازی سشن امن و ایجاد اتصال PDO پیاده‌سازی و تست شده است. در مراحل بعد، لود روت‌ها و اجرای Router اضافه خواهد شد. همچنین طبق اصول Clean Code، در فاز نهایی منطق‌های داخلی سشن و ساخت دیتابیس به کلاس‌های اختصاصی منتقل می‌شوند تا Front Controller کاملاً سبک و تک‌مسئولیتی (SRP) باقی بماند.

---

# مرحله 2 — فایل‌های Http، Helper و Router

## `App/Http/Request.php`

تابع `isAjaxRequest()` قبلاً در `App/Http/Request.php:3-9` کپی شده است:

| وضعیت | کدی که کپی می‌کنی | محل Paste در `App/Http/Request.php` |
| --- | --- | --- |
| انجام شده؛ دوباره کپی نکن | `libs/helpers.php:7-12` | کد فعلی `App/Http/Request.php:3-9` را داخل متد `isAjax()` قرار بده. |
| هنوز انجام نشده | منطق خواندن `$_SERVER['REQUEST_METHOD']` از `auth.php:22` | داخل متد `method()`؛ بلافاصله بعد از `isAjax()` |
| هنوز انجام نشده | منطق خواندن URI از `$_SERVER['REQUEST_URI']` | داخل متد `uri()`؛ بلافاصله بعد از `method()` |
| هنوز انجام نشده | منطق خواندن Query از `auth.php:23` | داخل متد `query()` و `queryString()`؛ بعد از `uri()` |
| هنوز انجام نشده | الگوی خواندن POST از `auth.php:24-29` | داخل متد `post()` و `postString()`؛ بعد از `queryString()` |
| هنوز انجام نشده | الگوی خواندن Cookie از `libs/helpers.php:38-40` | داخل متد `cookie()` و `cookieString()`؛ بعد از `postString()` |
| هنوز انجام نشده | متد عمومی خواندن ورودی (`post` یا `query`) | داخل متد `input()`؛ بعد از `cookieString()` |

بعد از Paste:

- ابتدا namespace `App\Http` و کلاس `final class Request` را ایجاد کن.
- `$_GET`, `$_POST`, `$_SERVER`, `$_COOKIE` فقط از طریق این کلاس دریافت شوند.
- متد `createFromGlobals(): self` برای نمونه‌سازی راحت اضافه شود.

## `App/Http/Response.php`

تابع `diepage()` قبلاً در انتهای فایل کپی شده است. آن را دوباره از `libs/helpers.php` کپی نکن:

| وضعیت | کدی که جابه‌جا یا کپی می‌کنی | محل Paste در `App/Http/Response.php` |
| --- | --- | --- |
| کپی شده؛ فقط جابه‌جا شود | `App/Http/Response.php:36-40` | این کد را Cut کن و داخل کلاس، به متد استاتیک `text(string $text, int $status = 200): self` تبدیل کن. |
| هنوز انجام نشده | الگوی JSON در `bootstrap/ajaxHandler.php:95-103` | داخل متد استاتیک `json(mixed $data, int $status = 200): self`؛ بعد از `text()` |
| هنوز انجام نشده | الگوی View و رندر Template با `extract` | داخل متد استاتیک `view(string $viewPath, array $data = [], int $status = 200): self`؛ بعد از `json()` |

بعد از Paste:

- کد procedural خطوط 36-40 از انتهای فایل به کلی حذف شود.
- متد `send(): never` آخرین متد کلاس باشد.

## `App/Http/Router.php`

یک کلاس جدید `final class Router` در مسیر `App/Http/Router.php` با قابلیت‌های زیر ایجاد کن:

1. ثبت روت‌های GET با متد `get(string $path, array|callable $handler, array $middlewares = []): self`
2. ثبت روت‌های POST با متد `post(string $path, array|callable $handler, array $middlewares = []): self`
3. متد `dispatch(Request $request): Response` که:
   - مسیر و متد درخواست را با لیست روت‌ها مطابقت دهد.
   - میدلورهای تعریف‌شده برای روت را به ترتیب اجرا کند.
   - هندلر روت (Controller و Action) را فراخوانی کرده و یک شیء `Response` بازگرداند.
   - در صورت پیدا نشدن روت، پاسخ 404 برگرداند.

## `App/Helpers/TimezoneHelper.php`

هر دو تابع از قبل در `App/Helpers/TimezoneHelper.php:3-23` وجود دارند. هیچ خطی را دوباره از `libs/helpers.php` کپی نکن. فقط:

1. namespace `App\Helpers` و کلاس `final class TimezoneHelper` را اضافه کن.
2. متدهای استاتیک `getApplicationTimezone(): DateTimeZone` و `getClientTimezone(?string $cookieTimezone = null): DateTimeZone` را بساز.
3. تابع کمکی `formatNotificationDate(string $dateTime, ?DateTimeZone $timezone = null): string` از `bootstrap/ajaxHandler.php:73-79` را نیز به عنوان متد استاتیک به این کلاس اضافه کن.

## `App/Middleware/CsrfMiddleware.php`

یک کلاس `final class CsrfMiddleware` تحت فضای نام `App\Middleware` بساز:

| ترتیب | کدی که کپی می‌کنی | محل Paste |
| --- | --- | --- |
| 1 | `libs/lib-auth.php:294-301` | داخل متد `getToken(): string` |
| 2 | `libs/lib-auth.php:303-309` | داخل متد `isValid(mixed $token): bool` |
| 3 | اعتبارسنجی خودکار در درخواست‌های POST | داخل متد `handle(Request $request): ?Response` |

## `App/Middleware/AuthMiddleware.php`

یک کلاس `final class AuthMiddleware` تحت فضای نام `App\Middleware` بساز:

1. بررسی وضعیت لاگین کاربر از سشن (`index.php:4-7` و `bootstrap/ajaxHandler.php:4-7`).
2. داخل متد `handle(Request $request): ?Response`:
   - اگر کاربر لاگین نبود:
     - برای درخواست‌های Ajax پاسخ `Response::json(['success' => false, 'message' => 'Authentication required.'], 401)` بدهد.
     - برای سایر درخواست‌ها با `Response::redirect(BASE_URL . 'auth.php')` هدایت کند.

---

# مرحله 3 — Avatar، Profile و UserRepository

## `App/Helpers/AvatarHelper.php`

فایل را با namespace `App\Helpers` و کلاس `final class AvatarHelper` بساز. سپس کپی کن:

| ترتیب | کدی که کپی می‌کنی | نام متد در کلاس `AvatarHelper` |
| --- | --- | --- |
| 1 | `libs/lib-auth.php:88-100` | `public static function hashCode(string $name): int` |
| 2 | `libs/lib-auth.php:103-106` | `public static function digit(int $hash, int $index): int` |
| 3 | `libs/lib-auth.php:108-117` | `public static function unit(int $hash, int $index, int $max = 100): int` |
| 4 | `libs/lib-auth.php:119-128` | `public static function contrast(string $color): string` |
| 5 | `libs/lib-auth.php:130-194` | `public static function createBoringBeamAvatarSvg(string $name, array $colors = [], int $size = 40): string` |

## `App/Services/ProfileService.php`

فایل را با namespace `App\Services` و کلاس `final class ProfileService` بساز (تزریق وابستگی `UserRepository` در Constructor):

| ترتیب | کدی که کپی می‌کنی | محل Paste و نام متد |
| --- | --- | --- |
| 1 | `libs/lib-auth.php:196-205` | متد `getStorageDirectory(): string` |
| 2 | `libs/lib-auth.php:207-223` | متد `writeAvatarFile(int $userId, string $contents, string $extension): string` |
| 3 | `libs/lib-auth.php:225-272` | متد `storeAvatar(int $userId, string $action, int $choice, string $dataUrl): string` |
| 4 | `libs/lib-auth.php:274-292` | متد `deleteAvatar(string $avatarPath): void` |
| 5 | `index.php:62-104` | متد `validateProfile(array $profileInput, string $avatarAction, string $avatarChoiceValue, ?DateTimeZone $userTimezone): array` |
| 6 | `index.php:106-137` | متد `updateProfile(int $userId, array $profileData, string $avatarAction, int $avatarChoice, string $avatarData): void` |

نکات پس از انتقال:

- ساخت آواتار SVG را از `AvatarHelper::createBoringBeamAvatarSvg` فراخوانی کن.
- شناسه `$userId` همیشه به عنوان پارامتر ارسال شود و از سشن یا توابع سراسری خوانده نشود.

## `App/Repositories/UserRepository.php`

فایل را با namespace `App\Repositories` و کلاس `final class UserRepository` بساز (`PDO` در Constructor تزریق شود):

| ترتیب | کدی که کپی می‌کنی | نام متد در کلاس `UserRepository` |
| --- | --- | --- |
| 1 | `libs/lib-auth.php:311-325` | `public function findByUsername(string $username): ?object` |
| 2 | `libs/lib-auth.php:327-330` | `public function usernameExists(string $username): bool` |
| 3 | `libs/lib-auth.php:332-345` | `public function emailExists(string $email): bool` |
| 4 | `libs/lib-auth.php:470-485` | `public function create(string $email, string $username, string $passwordHash): int` |
| 5 | `libs/lib-auth.php:16-41` | `public function getProfile(int $userId): ?object` |
| 6 | `libs/lib-auth.php:43-86` | `public function updateProfile(int $userId, array $profileData): void` |
| 7 | `libs/lib-auth.php:413-420` | `public function findPasswordHashById(int $userId): ?string` |
| 8 | `libs/lib-auth.php:387-395` | `public function updatePasswordHash(int $userId, string $passwordHash): void` |

نکات پس از انتقال:

- تمام `global $pdo` حذف و از `$this->pdo` استفاده شود.
- تمام `getCurrentUserId()` حذف و `$userId` به عنوان آرگومان متد دریافت شود.

## `App/Controllers/ProfileController.php`

فایل را با namespace `App\Controllers` و کلاس `final class ProfileController` بساز (تزریق `ProfileService` و `UserRepository`):

| کدی که کپی می‌کنی | متد مقصد |
| --- | --- |
| `index.php:23-30` | متد `show(Request $request): Response` |
| `index.php:32-60` و `index.php:106-139` | متد `update(Request $request): Response` |

---

# مرحله 4 — Auth

## `App/Services/AuthService.php`

کلاس `AuthService` در حال حاضر متد `logout()` را دارد. توابع زیر را به آن اضافه کن (تزریق `UserRepository` در Constructor):

| ترتیب | کدی که کپی می‌کنی | نام متد در کلاس `AuthService` |
| --- | --- | --- |
| 1 | `libs/lib-auth.php:4-8` | `public function getCurrentUser(): ?array` |
| 2 | `libs/lib-auth.php:11-14` | `public function getCurrentUserId(): int` |
| 3 | `libs/lib-auth.php:347-356` | `public function setAuthenticatedUser(object $user): void` |
| 4 | `libs/lib-auth.php:358-366` | `public function verifyPassword(string $password, string $storedPassword): bool` |
| 5 | `libs/lib-auth.php:368-401` | `public function login(string $username, string $password): bool` |
| 6 | `libs/lib-auth.php:403-445` | `public function changePassword(int $userId, string $currentPassword, string $newPassword): bool` |
| 7 | `libs/lib-auth.php:447-468` | `public function validateNewPassword(string $newPassword, string $confirmation): void` |
| 8 | `libs/lib-auth.php:470-485` | متد `public function register(string $email, string $username, string $password): int` (با فراخوانی `UserRepository->create`) |
| 9 | `App/Services/AuthService.php:9-30` | متد `logout(): void` (قبلاً پیاده شده است) |

## `App/Controllers/AuthController.php`

کلاس `AuthController` در حال حاضر متد `logout()` را دارد. متدهای زیر را قبل از آن اضافه کن:

| کدی که کپی می‌کنی | نام متد در `AuthController` |
| --- | --- |
| `auth.php:9-20` | `public function showLogin(Request $request): Response` |
| `auth.php:22-44` | `public function login(Request $request): Response` |
| `auth.php:45-92` | `public function register(Request $request): Response` |
| `bootstrap/ajaxHandler.php:118-160` | `public function changePassword(Request $request): Response` (پاسخ JSON) |

---

# مرحله 5 — Task و Reminder

## `App/Services/ReminderService.php`

فایل را با namespace `App\Services` و کلاس `final class ReminderService` بساز:

| کدی که کپی می‌کنی | نام متد در `ReminderService` |
| --- | --- |
| `libs/lib-tasks.php:25-112` | `public function prepareTaskReminders(array $reminders, ?DateTimeInterface $dueAt, bool $hasTime): array` |
| `bootstrap/ajaxHandler.php:45-58` | `public function readTaskReminders(string $remindersJson): array` |
| `bootstrap/ajaxHandler.php:263-274` | `public function previewReminders(array $preparedReminders): array` |

## `App/Repositories/TaskRepository.php`

فایل را با namespace `App\Repositories` و کلاس `final class TaskRepository` بساز (`PDO` در Constructor تزریق شود):

| ترتیب | کدی که کپی می‌کنی | نام متد در `TaskRepository` |
| --- | --- | --- |
| 1 | `libs/lib-tasks.php:12-23` | `public function deleteTask(int $taskId, int $userId): int` |
| 2 | `libs/lib-tasks.php:167-180` | `public function getActiveTasks(int $userId): array` |
| 3 | `libs/lib-tasks.php:182-219` | `public function getTasksForDate(int $userId, DateTimeInterface $date, ?DateTimeInterface $showCompletedSince = null): array` |
| 4 | `libs/lib-tasks.php:220-246` | `public function getTasksWithoutDueDate(int $userId, ?DateTimeInterface $showCompletedSince = null): array` |
| 5 | `libs/lib-tasks.php:247-262` | `public function getCompletedTasks(int $userId): array` |
| 6 | `libs/lib-tasks.php:325-349` | `public function countCompletedTasksForDate(int $userId, DateTimeInterface $date): int` |
| 7 | `libs/lib-tasks.php:128-138` | `public function insertTask(int $userId, string $title, ?DateTimeInterface $dueAt, bool $hasTime): int` |
| 8 | `libs/lib-tasks.php:275-286` | `public function findTaskForUpdate(int $taskId, int $userId): ?object` |
| 9 | `libs/lib-tasks.php:296-308` | `public function updateTaskCompletion(int $taskId, int $userId, bool $isDone, ?DateTimeImmutable $completedAt): void` |

## `App/Repositories/ReminderRepository.php`

فایل را با namespace `App\Repositories` و کلاس `final class ReminderRepository` بساز (`PDO` در Constructor تزریق شود):

| ترتیب | کدی که کپی می‌کنی | نام متد در `ReminderRepository` |
| --- | --- | --- |
| 1 | `libs/lib-tasks.php:141-153` | `public function insertReminders(int $taskId, array $preparedReminders): void` |
| 2 | `libs/lib-notifications.php:5-54` | `public function getUserNotifications(int $userId, ?string $status = null): array` |
| 3 | `libs/lib-notifications.php:56-59` | `public function getUserSentNotifications(int $userId): array` |
| 4 | `libs/lib-notifications.php:61-75` | `public function countUserSentNotifications(int $userId): int` |
| 5 | `libs/lib-notifications.php:89-105` | `public function findNotificationForUpdate(int $notificationId, int $userId): ?object` |
| 6 | `libs/lib-notifications.php:131-147` | `public function updateNotification(int $notificationId, array $reminderData): void` |
| 7 | `libs/lib-notifications.php:184-197` | `public function cancelNotification(int $notificationId, int $userId): bool` |

## `App/Services/TaskService.php`

فایل را با namespace `App\Services` و کلاس `final class TaskService` بساز (تزریق `TaskRepository`، `ReminderRepository`، `ReminderService` و `PDO`):

| ترتیب | کدی که کپی می‌کنی | نام متد در `TaskService` |
| --- | --- | --- |
| 1 | `libs/lib-tasks.php:114-165` | `public function addTask(int $userId, string $title, ?DateTimeInterface $dueAt, bool $hasTime, array $reminders): int` |
| 2 | `libs/lib-tasks.php:264-323` | `public function toggleTaskCompletion(int $taskId, int $userId): object` |

## `App/Controllers/TaskController.php`

فایل را با namespace `App\Controllers` و کلاس `final class TaskController` بساز:

| کدی که کپی می‌کنی | نام متد در `TaskController` |
| --- | --- |
| `index.php:149-160` | `public function home(Request $request): Response` |
| `index.php:142` | `public function index(Request $request): Response` (Manage Tasks) |
| `index.php:148` و `index.php:152-154` | `public function activity(Request $request): Response` |
| `index.php:11-14` | `public function delete(Request $request): Response` |
| `bootstrap/ajaxHandler.php:288-332` | `public function add(Request $request): Response` (Ajax) |
| `bootstrap/ajaxHandler.php:82-117` | `public function toggleCompletion(Request $request): Response` (Ajax) |
| `bootstrap/ajaxHandler.php:24-43` | متد کمکی خصوصی `private function parseTaskDueAt(string $dueAtValue): ?DateTimeImmutable` |
| `bootstrap/ajaxHandler.php:60-71` | متد کمکی خصوصی `private function readHasTimeValue(Request $request): bool` |

---

# مرحله 6 — Notification

## `App/Services/NotificationService.php`

فایل را با namespace `App\Services` و کلاس `final class NotificationService` بساز (تزریق `ReminderRepository`، `ReminderService` و `PDO`):

| ترتیب | کدی که کپی می‌کنی | نام متد در `NotificationService` |
| --- | --- | --- |
| 1 | `libs/lib-notifications.php:56-59` | `public function getSentNotifications(int $userId): array` |
| 2 | `libs/lib-notifications.php:77-174` | `public function updateNotification(int $notificationId, int $userId, int $offsetValue, string $offsetUnit): object` |
| 3 | `libs/lib-notifications.php:176-198` | `public function cancelNotification(int $notificationId, int $userId): bool` |

## `App/Controllers/NotificationController.php`

فایل را با namespace `App\Controllers` و کلاس `final class NotificationController` بساز:

| کدی که کپی می‌کنی | نام متد در `NotificationController` |
| --- | --- |
| `index.php:143` | `public function messages(Request $request): Response` |
| `index.php:144-147` | `public function sentNotifications(Request $request): Response` |
| `bootstrap/ajaxHandler.php:161-208` | `public function update(Request $request): Response` (Ajax) |
| `bootstrap/ajaxHandler.php:209-244` | `public function cancel(Request $request): Response` (Ajax) |

## `App/Controllers/ReminderController.php`

فایل را با namespace `App\Controllers` و کلاس `final class ReminderController` بساز:

- متد `preview(Request $request): Response` از روی `bootstrap/ajaxHandler.php:245-287` ساخته می‌شود که داده‌ها را از `ReminderService` گرفته و پاسخ JSON برمی‌گرداند.

## فایل‌های Web Push (در صورت نیاز به قابلیت Background Push)

- `App/Models/Reminder.php`
- `App/Notifications/NotificationSender.php`
- `App/Notifications/WebPushNotificationSender.php`
- `process/send-reminders.php`

---

# مرحله 7 — Viewها و Layoutها

## `views/layouts/dashboard.php`

ساختاربندی پوسته اصلی داشبورد:

1. بخش Head و تگ‌های پایه HTML (`views/view-index.php:118-149`)
2. فراخوانی کامپوننت Header (`views/components/dashboard-header.php`)
3. فراخوانی کامپوننت Sidebar (`views/components/sidebar.php`)
4. رندر محتوای صفحه اصلی از `$contentView`
5. بخش اسکریپت‌ها و بستن تگ‌های HTML (`views/view-index.php:236-239`)

## تفکیک کامپوننت‌ها

- `views/components/dashboard-header.php`: خطوط `views/view-index.php:151-200`
- `views/components/sidebar.php`: خطوط `views/view-index.php:202-232`
- `views/components/task-toolbar.php`: خطوط `views/view-index.php:82-98`
- `views/components/task-modals.php`: خطوط `views/components/dashboard-view.php:52-59`
- `views/components/notification-formatters.php`: خطوط `views/view-index.php:47-66`

## Pageها و Modalها

- `views/pages/auth.php`: کل فایل `views/views-auth.php`
- سایر صفحات در `views/pages/` و مودال‌ها در `views/modals/` حفظ می‌شوند و متغیرها مستقیماً توسط Controllerها از طریق `Response::view` به آن‌ها پاس داده می‌شوند.
- منطق انتخاب صفحه بر اساس View جایگزین و توسط Router مدیریت می‌شود.

---

# مرحله 8 — Routeها

## `routes/web.php`

تعریف مسیرهای وب (HTML):

```php
$router->get('/auth', [AuthController::class, 'showLogin']);
$router->post('/login', [AuthController::class, 'login']);
$router->post('/register', [AuthController::class, 'register']);
$router->post('/logout', [AuthController::class, 'logout'], [AuthMiddleware::class]);

$router->get('/', [TaskController::class, 'home'], [AuthMiddleware::class]);
$router->get('/home', [TaskController::class, 'home'], [AuthMiddleware::class]);
$router->get('/tasks', [TaskController::class, 'index'], [AuthMiddleware::class]);
$router->get('/activity', [TaskController::class, 'activity'], [AuthMiddleware::class]);
$router->get('/messages', [NotificationController::class, 'messages'], [AuthMiddleware::class]);
$router->get('/notifications', [NotificationController::class, 'sentNotifications'], [AuthMiddleware::class]);
$router->get('/profile', [ProfileController::class, 'show'], [AuthMiddleware::class]);
$router->post('/profile', [ProfileController::class, 'update'], [AuthMiddleware::class]);
$router->get('/change-password', [ProfileController::class, 'showChangePassword'], [AuthMiddleware::class]);
$router->get('/account-settings', [ProfileController::class, 'showAccountSettings'], [AuthMiddleware::class]);
```

## `routes/api.php`

تعریف مسیرهای ایجکس و API:

```php
$router->post('/api/tasks', [TaskController::class, 'add'], [AuthMiddleware::class]);
$router->post('/api/tasks/toggle', [TaskController::class, 'toggleCompletion'], [AuthMiddleware::class]);
$router->post('/api/tasks/delete', [TaskController::class, 'delete'], [AuthMiddleware::class]);
$router->post('/api/password/change', [AuthController::class, 'changePassword'], [AuthMiddleware::class]);
$router->post('/api/notifications/update', [NotificationController::class, 'update'], [AuthMiddleware::class]);
$router->post('/api/notifications/cancel', [NotificationController::class, 'cancel'], [AuthMiddleware::class]);
$router->post('/api/reminders/preview', [ReminderController::class, 'preview'], [AuthMiddleware::class]);
```

---

# مرحله 9 — Assets و پاکسازی فایل‌های قدیمی

1. انتقال دارایی‌ها: انتقال پوشه `assets/` به `public/assets/`
2. اطمینان از تنظیم مسیر `storage/avatars/`
3. تست نهایی تمام سناریوهای کاربری (ورود، ثبت نام، پروفایل، تسک‌ها، اعلان‌ها و ...)
4. پس از تأیید سلامت کامل برنامه، حذف فایل‌های زیر:
   - `auth.php`
   - `index.php`
   - `logout.php`
   - `bootstrap/ajaxHandler.php`
   - `bootstrap/init.php`
   - `bootstrap/config.php`
   - `bootstrap/constant.php`
   - `libs/helpers.php`
   - `libs/lib-auth.php`
   - `libs/lib-tasks.php`
   - `libs/lib-notifications.php`
   - `views/view-index.php`
   - `views/views-auth.php`
   - `views/components/dashboard-view.php`

---

# بهبودهای معماری و Clean Code (فاز بهینه‌سازی و Refactor)

پس از راه‌اندازی و تست کامل معماری MVC، موارد زیر جهت ارتقای تمیزی کد و رعایت استانداردهای SOLID انجام خواهد شد:

1. **کپسوله‌سازی مدیریت Session (`App\Http\SessionManager`):**
   - انتقال منطق ساخت پوشه موقت، اعتبارسنجی محیط محلی/HTTPS، تنظیم کوکی‌های امن و هندلینگ `SessionInitializationException` از `public/index.php` به کلاس `SessionManager`.
   - فراخوانی ساده در نقطه ورود: `SessionManager::start();`

2. **کپسوله‌سازی اتصال پایگاه داده (`App\Database\Database`):**
   - انتقال منطق ساخت DSN، ساخت شیء PDO، و مدیریت `PDOException` به متد `Database::connect($databaseConfig)`.

3. **ساده‌سازی نهایی Front Controller (`public/index.php`):**
   - رساندن حجم `public/index.php` به یک اسکریپت فوق‌العاده خوانا و حدود ۲۰ خطی (پایبندی کامل به Single Responsibility Principle):

     ```php
     <?php
     $rootPath = dirname(__DIR__);
     require_once $rootPath . '/vendor/autoload.php';

     $appConfig = require_once $rootPath . '/config/app.php';
     $databaseConfig = require_once $rootPath . '/config/database.php';

     date_default_timezone_set($appConfig['timezone']);

     \App\Http\SessionManager::start();
     $pdo = \App\Database\Database::connect($databaseConfig);

     $request = \App\Http\Request::createFromGlobals();
     $router = require_once $rootPath . '/routes/web.php';
     require_once $rootPath . '/routes/api.php';

     $response = $router->dispatch($request);
     $response->send();
     ```

---

# ترتیب اجرای کار

1. تکمیل کلاس‌های `Request`، `Response`، `Router`، `TimezoneHelper` و `Middleware`ها (مرحله ۲)
2. ساخت `AvatarHelper`، `ProfileService`، `UserRepository` و `ProfileController` (مرحله ۳)
3. ساخت `AuthService` و `AuthController` (مرحله ۴)
4. ساخت `ReminderService`، `TaskRepository`، `ReminderRepository`، `TaskService` و `TaskController` (مرحله ۵)
5. ساخت `NotificationService`، `NotificationController` و `ReminderController` (مرحله ۶)
6. ساختاربندی Viewها و Layoutها (مرحله ۷)
7. اتصال Routeها در `routes/web.php` و `routes/api.php` و فعال‌سازی در `public/index.php` (مرحله ۸)
8. انتقال Assets به `public/assets` و هماهنگ‌سازی مسیرها در JS/CSS (مرحله ۹)
9. تست کامل کل پروژه و سپس پاکسازی فایل‌های Legacy.
10. اجرای فاز Refactor و اعمال بهبودهای Clean Code در `public/index.php` و کلاس‌های زیرساختی.

> بعد از تغییر هر فایل PHP، بررسی خطای سینتکس با `php -l` الزامی است. هیچ فایل مبدأ تا قبل از تست نهایی حذف نخواهد شد.
