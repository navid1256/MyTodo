# MyTodo Roadmap

این فایل فقط کارهایی را نگه می‌دارد که هنوز باید در آینده انجام شوند. قابلیت‌هایی که اکنون پیاده‌سازی شده‌اند، در این فهرست تکرار نشده‌اند.

آخرین بازبینی: 2026-09-03

## قواعد ثابت پروژه

- تاریخ‌ها در دیتابیس و API به‌صورت Gregorian و UTC ذخیره شوند؛ تبدیل به Jalali و منطقه زمانی کاربر فقط در لایه ورودی و نمایش انجام شود.
- سیستم Folder دوباره به پروژه برنگردد؛ هر Task مستقیماً متعلق به یک User است.
- تاریخچه ورود کاربران ساخته نشود.
- برای نسخه PWA از Web Push استفاده شود. FCM فقط زمانی بررسی شود که نسخه Native یا Capacitor ساخته شود.
- Service Worker باید در ریشه عمومی پروژه قرار بگیرد تا کل برنامه را پوشش دهد.
- اطلاعات حساس مانند رمز دیتابیس و VAPID Private Key داخل Git ذخیره نشوند.

## اولویت 0: آماده‌سازی پایه و امنیت

- [x] هشدارهای امنیتی Composer برطرف شدند.
  - وضعیت اعلام‌شده: `composer audit` دیگر هشدار امنیتی گزارش نمی‌کند.
- [x] تنظیمات محیطی از کد جدا شوند.
  - اطلاعات دیتابیس، VAPID keys و تنظیمات production از Environment Variable یا فایل تنظیمات خارج از Git خوانده شوند.
  - یک فایل نمونه مانند `.env.example` بدون مقدار واقعی ساخته شود.
  - `.env` و فایل‌های کلید خصوصی توسط Git نادیده گرفته می‌شوند و مقدارهای واقعی سرور بر `.env` اولویت دارند.
- [x] مدیریت خطا برای محیط production تکمیل شود.
  - خطای خام PDO یا Stack Trace به کاربر نمایش داده نشود.
  - خطاهای سرور در فایل Log ثبت شوند و برای کاربر پیام عمومی نمایش داده شود.
  - خطاهای HTML و JSON به‌صورت مرکزی مدیریت و در `storage/logs/app.log` ثبت می‌شوند.
- [x] Schema اصلی و Migrationها یکسان‌سازی شوند.
  - نصب یک دیتابیس تازه باید دقیقاً همان ساختار دیتابیس به‌روزشده را بسازد.
  - برای `tasks.user_id` کلید خارجی به `users.id` اضافه شود.
  - Charset ستون‌های متنی روی `utf8mb4` یکسان شود.
- [x] تمام عملیات تغییر داده فقط با `POST` و CSRF انجام شوند.
  - حذف Task از Query String و درخواست `GET` خارج شود.
  - حذف Task به endpoint امن AJAX منتقل شود.
  - مالکیت Task داخل Query حذف بررسی شود و Reminderها فقط پس از حذف مجاز Task با Foreign Key Cascade پاک شوند.

## اولویت 1: زمان، منطقه زمانی و Account Settings

- [x] جدول تنظیمات کاربر ساخته شود.
  - مقادیر `user_id`، `language`، `calendar_system` و `timezone` ذخیره شوند.
  - برای هر User فقط یک ردیف تنظیمات وجود داشته باشد.
- [x] انتخاب‌های Account Settings در دیتابیس ذخیره شوند.
  - `localStorage` فقط Cache یا fallback مرورگر باشد، نه منبع اصلی اطلاعات.
  - ذخیره تنظیمات با AJAX انجام شود و پیام موفقیت یا خطا نمایش داده شود.
- [x] ذخیره Account Settings فقط پس از کلیک روی دکمه `Save` انجام شود.
  - تغییر Dropdownهای Calendar System، Language و Time Zone به‌تنهایی اطلاعات را ذخیره نکند.
  - دکمه `Save` در پایین سمت راست صفحه قرار بگیرد و هر سه مقدار را با یک درخواست AJAX ذخیره کند.
  - هنگام ارسال، دکمه موقتاً غیرفعال شود و پس از پاسخ، پیام موفقیت یا خطای معتبر نمایش داده شود.
  - تنظیم جدید تقویم فقط پس از ذخیره موفق و بدون Reload صفحه در برنامه اعمال شود.
  - پیام اعتبارسنجی قبل از تلاش کاربر برای ذخیره نمایش داده نشود.
- [x] منطقه زمانی واقعی کاربر به‌صورت پایدار ذخیره شود.
  - استفاده مستقیم از `Asia/Tehran` در Controllerها، Serviceها و Notificationها حذف شود.
  - زمان ورودی کاربر به UTC تبدیل و زمان خروجی از UTC به Timezone کاربر تبدیل شود.
  - تغییر Timezone نباید زمان واقعی Task و Reminder را جابه‌جا کند.
- [x] مقدار `Default` برای Language تعریف روشنی داشته باشد.
  - در حالت Default از زبان مرورگر استفاده شود.
  - در صورت پشتیبانی‌نشدن زبان مرورگر، English انتخاب شود.

## اولویت 2: فارسی‌سازی و تقویم Jalali

- [x] مرحله اول تقویم Jalali فقط روی تمام تقویم‌های تعاملی پیاده‌سازی شود.
  - تقویم Manage Tasks
  - تقویم Set Date & Time
  - تقویم پایان Repeat
  - تقویم تاریخ تولد در My Profile
  - تبدیل تاریخ‌های متنی Home، Activity، Messages و Sent Notifications در مرحله لایه مرکزی نمایش و ترجمه انجام شود.
- [ ] لایه مرکزی ترجمه برای English و Persian ساخته شود.
  - [x] کلاس مرکزی `Translator` با fallback انگلیسی ساخته شد.
  - [x] فایل‌های ترجمه `resources/lang/en.php` و `resources/lang/fa.php` ساخته شدند.
  - [x] زبان و جهت پایه سند با `lang` و `dir` در Layout مرکزی تنظیم می‌شوند.
  - [x] متن‌های مشترک Header، Sidebar و Task Toolbar از Translator خوانده می‌شوند.
  - [x] صفحه Account Settings، پیام‌های AJAX و خطاهای Validation آن به Translator متصل شدند.
  - [x] تغییر English و Persian بعد از Save بدون Reload روی صفحه و پوسته مشترک اعمال می‌شود.
  - [x] صفحه My Profile، انتخاب آواتار، تقویم تاریخ تولد و خطاهای Profile به Translator متصل شدند.
  - [ ] متن دکمه‌ها، Placeholderها، Statusها و عنوان تمام صفحه‌ها به فایل‌های ترجمه منتقل شوند.
  - [ ] پیام‌های خطا و متن‌های تولیدشده در JavaScript به لایه ترجمه متصل شوند.
  - [ ] چیدمان اجزای لازم در حالت Persian از نظر RTL و Responsive کامل و آزمایش شود.
- [ ] Verta در Backend برای تبدیل و فرمت تاریخ‌های Jalali استفاده شود.
- [x] کتابخانه `jalaali-js` برای محاسبات و تبدیل تاریخ تقویم‌های تعاملی نصب و از طریق Vite وارد شود.
  - [x] نسخه `2.0.1` به‌عنوان Runtime Dependency نصب شد.
  - [x] کتابخانه در هسته مشترک تقویم از طریق Vite وارد شود.
- [x] یک هسته مشترک تقویم برای Gregorian و Jalali ساخته شود تا چهار تقویم تعاملی منطق تکراری نداشته باشند.
  - `jalaali-js` مسئول تبدیل، محاسبه تعداد روزهای ماه، سال کبیسه و اعتبارسنجی Client باشد.
  - `Intl.DateTimeFormat` مسئول نام فارسی ماه‌ها و روزها و اعداد فارسی باشد.
  - تغییر Gregorian به Jalali و برعکس باید همان روز واقعی را حفظ کند و فقط نمایش را تغییر دهد.
- [x] رابط تقویم Jalali همیشه فارسی باشد؛ حتی اگر Language برنامه روی English قرار داشته باشد.
  - نام ماه‌ها و روزهای هفته و تمام اعداد تاریخ با نویسه‌های فارسی نمایش داده شوند.
  - فونت Vazirmatn با وزن‌های Regular 400 و SemiBold 600 به‌صورت Self-hosted فقط برای رابط تقویم Jalali اضافه شود.
  - تقویم RTL باشد؛ شنبه در راست‌ترین ستون و جمعه در چپ‌ترین ستون قرار بگیرد.
  - فلش سمت راست ماه بعد و فلش سمت چپ ماه قبل را نمایش دهد.
  - تاریخ انتخاب‌شده در رابط با قالبی مانند `۱۰ شهریور ۱۴۰۵` نمایش داده شود.
- [x] تقویم تاریخ تولد اختصاصی جایگزین ورودی Native مرورگر شود.
  - انتخاب ماه و سال با Dropdown انجام شود.
  - سال Jalali از ۱۳۰۰ تا سال جاری قابل انتخاب باشد.
  - ماه‌ها با نام فارسی و سال‌ها با اعداد فارسی نمایش داده شوند.
  - انتخاب تاریخ آینده مجاز نباشد.
- [ ] تبدیل تاریخ ورودی Jalali به Gregorian/UTC قبل از ذخیره انجام شود.
  - مقدار Canonical و مخفی ارسال‌شده به Backend برای تاریخ به‌شکل Gregorian `YYYY-MM-DD` باقی بماند.
  - زمان براساس Time Zone کاربر به UTC تبدیل شود؛ تغییر نوع تقویم نباید لحظه واقعی را تغییر دهد.
- [ ] سال کبیسه و تعداد روز ماه‌های Jalali و Gregorian در Client و Server اعتبارسنجی شوند.

## اولویت 3: تکمیل سیستم Repeat

در حال حاضر Modal و اعتبارسنجی Frontend آماده است، اما `repeat_config` در Backend ذخیره و اجرا نمی‌شود.

- [ ] مدل دیتابیس برای Repeat Rule طراحی و Migration آن ساخته شود.
  - Frequency شامل Daily، Weekly، Monthly و Custom باشد.
  - Interval، روزهای هفته، روز ماه و گزینه Last day ذخیره شوند.
  - پایان تکرار شامل Endlessly، A date و Repeat Counts باشد.
- [ ] `repeat_config` در `TaskController` خوانده و در Server اعتبارسنجی شود.
- [ ] Rule هم‌زمان با Task و در یک Transaction ذخیره شود.
- [ ] موتور ساخت Taskهای تکرارشونده پیاده‌سازی شود.
  - رفتار Daily، Weekly، Monthly و Custom دقیقاً مشخص شود.
  - برای روزهای 29، 30 و 31، گزینه Last valid day of month پشتیبانی شود.
  - پایان براساس تاریخ یا تعداد دفعات رعایت شود.
- [ ] مشخص شود Task بعدی چه زمانی ساخته می‌شود.
  - پیشنهاد: پس از Complete شدن نمونه فعلی، نمونه بعدی ساخته شود.
  - اجرای Cron باید Taskهای عقب‌افتاده را نیز بدون ایجاد نمونه تکراری بازیابی کند.
- [ ] Reminderهای هر نمونه تکرارشونده با Due Time جدید دوباره محاسبه شوند.
- [ ] امکان Edit، Pause، Resume و Cancel کردن یک Rule اضافه شود.
- [ ] رفتار ویرایش مشخص شود: فقط این Task، این Task و Taskهای بعدی، یا تمام Series.

## اولویت 4: ارسال واقعی Notification با Web Push

جدول `task_reminders` اکنون زمان‌بندی Reminder را نگه می‌دارد؛ پکیج Web Push فقط مسئول تحویل پیام خواهد بود.

- [ ] VAPID Public/Private Keys ساخته و خارج از Repository نگهداری شوند.
- [ ] جدول `push_subscriptions` ساخته شود.
  - Subscription به User و Device/Browser متصل شود.
  - `endpoint`، `p256dh`، `auth`، زمان ایجاد و آخرین استفاده ذخیره شوند.
  - Endpoint تکراری ثبت نشود.
- [ ] UI فعال و غیرفعال کردن Notification ساخته شود.
  - Permission مرورگر فقط پس از اقدام مستقیم کاربر درخواست شود.
  - حالت‌های Granted، Denied و Unsupported به کاربر نمایش داده شوند.
- [ ] ثبت، به‌روزرسانی و حذف Subscription با AJAX و CSRF پیاده‌سازی شود.
- [ ] کلاس `WebPushNotificationSender` ساخته شود تا ارسال از منطق زمان‌بندی جدا بماند.
- [ ] فایل `process/send-reminders.php` ساخته شود.
  - Reminderهای `pending` و رسیده را در Batchهای محدود بخواند.
  - پس از موفقیت، `status=sent` و `sent_at` ثبت شود.
  - پس از خطا، `attempt_count` و `last_attempt_at` به‌روزرسانی شوند.
  - خطاهای موقت Retry و Subscriptionهای منقضی حذف یا غیرفعال شوند.
  - اجرای هم‌زمان دو Worker باعث ارسال تکراری نشود.
- [ ] Cron Job هاست یا Windows Task Scheduler برای اجرای دوره‌ای Sender تنظیم شود.
- [ ] Payload نوتیفیکیشن شامل عنوان Task، Due Time و URL بازکردن Task باشد.
- [ ] کلیک روی Push کاربر را به Task یا صفحه مناسب داخل برنامه ببرد.
- [ ] وضعیت خوانده‌شدن Notification اضافه شود.
  - Badge زنگوله تعداد Notificationهای ارسال‌شده و خوانده‌نشده را نشان دهد.
  - با مشاهده صفحه Sent Notifications، موارد مربوط به کاربر Read شوند.
- [ ] صفحه Notification برای حجم زیاد داده Pagination یا Load More داشته باشد.

## اولویت 5: تبدیل پروژه به PWA و اپ Android

- [ ] فایل `manifest.webmanifest` با نام، رنگ‌ها، start URL، display mode و iconها ساخته شود.
- [ ] iconهای استاندارد PWA در اندازه‌های لازم و نسخه Maskable ساخته شوند.
- [ ] `service-worker.js` در ریشه عمومی پروژه ساخته شود.
  - فایل‌های ضروری App Shell Cache شوند.
  - برای Cache نسخه‌بندی و حذف Cache قدیمی در نظر گرفته شود.
  - Offline fallback برای قطع اینترنت وجود داشته باشد.
  - رویدادهای `push` و `notificationclick` مدیریت شوند.
- [ ] ثبت Service Worker و مدیریت Update آن در Frontend انجام شود.
- [ ] Install Prompt مناسب برای نصب PWA اضافه شود.
- [ ] برنامه روی Android Chrome از نظر نصب، Push، Update و حالت Offline آزمایش شود.
- [ ] برنامه فقط روی HTTPS در Production منتشر شود.
- [ ] پس از پایدارشدن PWA، بسته‌بندی TWA برای انتشار Android بررسی شود.

## اولویت 6: تکمیل مدیریت Task

- [ ] ایجاد Task بدون `window.location.reload()` کامل شود.
  - Task جدید با پاسخ JSON به لیست درست اضافه شود.
  - Calendar markers و شمارنده Completed بدون Reload به‌روز شوند.
- [ ] امکان Edit کردن عنوان، تاریخ، زمان، Reminder و Repeat یک Task اضافه شود.
- [ ] حذف Task با AJAX، تأیید کاربر و امکان بازیابی کوتاه‌مدت یا Undo پیاده‌سازی شود.
- [ ] هنگام حذف Task، Reminderها و Repeat Ruleهای وابسته به‌درستی پاک یا Cancel شوند.
- [ ] رفتار Complete و Undo برای Task تکرارشونده مشخص و پیاده‌سازی شود.
- [ ] Race condition کلیک‌های سریع Complete/Undo کنترل شود.
- [ ] برای Taskهای زیاد Pagination یا Virtual/Incremental Rendering اضافه شود.

## اولویت 7: کیفیت، دسترس‌پذیری و Performance

- [ ] Vite به‌عنوان Build Tool پروژه راه‌اندازی شود.
  - [x] فایل‌های `package.json` و `package-lock.json` ساخته و Vite `8.2.2` در `devDependencies` نصب شد.
  - [x] پوشه `node_modules` در Git نادیده گرفته شد؛ `package.json` و `package-lock.json` باید در Git ثبت شوند.
  - [x] Script مربوط به `dev` تعریف شد.
  - [x] فایل `vite.config.js` برای معماری PHP پروژه ساخته شود.
  - [x] Vite Dev Server هم‌زمان با Apache/XAMPP و از طریق HTTPS اجرا شود.
    - [x] از Certificate محلی `mkcert` مربوط به `mytodo.php` استفاده شود.
    - [x] مسیر Certificate و Private Key در Git ثبت نشود.
    - [x] Mixed Content و اتصال HMR روی دامنه `https://mytodo.php` بررسی شد.
  - [x] در مرحله فعلی فقط Entry pointهای JavaScript به Vite متصل شوند و CSSهای موجود با Linkهای فعلی بارگذاری شوند.
  - [x] `jalaali-js` نسخه `2.0.1` از npm به‌عنوان Runtime Dependency نصب شد.
  - [x] `jalaali-js` از طریق ES Moduleهای Vite در هسته مشترک تقویم وارد شود.
  - [x] رفتار Development بدون Minify با مرورگر واقعی آزمایش شد.
  - [ ] تنظیمات Production Vite تا مرحله نهایی انتشار به تعویق بیفتد.
    - Scriptهای `build` و `preview` در آن مرحله تعریف شوند.
    - فایل‌های Minifyشده با نام Hashشده تولید شوند.
    - PHP مسیر Assetها را از `manifest.json` خروجی Vite بخواند.
    - پوشه خروجی Build در Git ذخیره نشود و فرایند Deployment آن مستند شود.
  - استفاده از Vite باعث اضافه‌شدن React، Astro یا Framework جدید نشود مگر اینکه بعداً نیاز واقعی آن تأیید شود.
- [ ] تست‌های Backend برای Auth، Task ownership، Reminder و Timezone نوشته شوند.
- [ ] تست‌های JavaScript برای Date، Reminder، Repeat و Navigation تکمیل شوند.
- [ ] تست End-to-End برای جریان‌های اصلی اضافه شود:
  - Register و Login
  - ساخت، ویرایش، Complete و حذف Task
  - فیلتر Activity
  - Repeat و Reminder
  - ذخیره Account Settings
  - دریافت و بازکردن Push Notification
- [ ] تمام Modalها از نظر Focus trap، Escape، بازگشت Focus و Screen Reader بررسی شوند.
- [ ] کنتراست رنگ‌ها در Light Mode و Dark Mode حداقل WCAG AA باشد.
- [ ] صفحه‌ها در Mobile، Tablet و Desktop بررسی و اصلاح شوند.
- [ ] فایل‌های قدیمی و استفاده‌نشده Font Awesome، CSS و JavaScript پس از بررسی وابستگی‌ها حذف شوند.
- [ ] حجم Font subset فقط شامل glyphهای مورد استفاده باقی بماند.
- [ ] Cache header، فشرده‌سازی Brotli/Gzip و نسخه‌گذاری assetها برای Production تنظیم شوند.
- [ ] Queryهای Task و Notification با داده زیاد Profile و Index شوند.
- [ ] معیارهای Performance با Lighthouse ثبت و قبل و بعد از تغییرات مقایسه شوند.

## اولویت 8: استقرار و مستندات

- [ ] README از نام قدیمی `7Todo` به `MyTodo` به‌روزرسانی شود.
- [ ] نسخه‌های واقعی PHP، MySQL/MariaDB و Composer در Requirements نوشته شوند.
- [ ] راهنمای نصب XAMPP و Import/Migration دیتابیس نوشته شود.
- [ ] راهنمای تنظیم HTTPS، VAPID، Cron و Web Push برای هاست اشتراکی نوشته شود.
- [ ] Backup دیتابیس و روش Restore مستند شود.
- [ ] تنظیمات Production برای Session، Cookie، Error Reporting و File Permission بررسی شوند.
- [ ] فرایند Release شامل Migration، Composer install، Cache cleanup و Smoke Test نوشته شود.

## معیار آماده‌بودن نسخه Production

- [ ] `composer audit` مشکل امنیتی مهم گزارش نکند.
- [ ] نصب تازه دیتابیس و اجرای تمام Migrationها موفق باشد.
- [ ] تمام زمان‌ها در چند Timezone و هر دو تقویم Gregorian/Jalali درست نمایش داده شوند.
- [ ] Taskهای Repeat بدون نمونه تکراری و با Reminder درست ساخته شوند.
- [ ] Web Push روی HTTPS و Android PWA در حالت بسته‌بودن صفحه کار کند.
- [ ] هیچ User نتواند Task، Profile، Subscription یا Notification کاربر دیگر را بخواند یا تغییر دهد.
- [ ] جریان‌های اصلی تست خودکار و Smoke Test دستی را پاس کنند.
- [ ] Backup و Restore دیتابیس حداقل یک‌بار عملاً آزمایش شده باشد.

## خارج از برنامه فعلی

- ساخت سیستم Folder
- ذخیره تاریخچه Login
- استفاده از FCM بدون نیاز مشخص به Native/Capacitor
- مهاجرت به React، Astro یا Framework جدید بدون مشکل واقعی و اندازه‌گیری‌شده
