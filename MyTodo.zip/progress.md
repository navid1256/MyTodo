Plan: RoadToMVC.md

Current status: ALL STAGES (1 to 8) COMPLETED SUCCESSFULLY!

Stage 1 (Config & Bootstrap): complete
- `config/app.php` returns `title`, `base_path`, `base_url`, and `timezone`.
- `config/database.php` returns clean database settings array with PDO options.
- `App/Http/SessionManager.php` encapsulates secure session startup, loopback/HTTPS protection, and custom session exceptions.
- `App/Database/Database.php` encapsulates secure PDO connection creation with DSN building and exception handling.
- `public/index.php` refactored into a concise Front Controller adhering 100% to SRP and Clean Code.

Stage 2 (HTTP, Router, Helper & Middleware): complete
- `App/Http/Request.php` encapsulates `$_GET`, `$_POST`, `$_SERVER`, and `$_COOKIE` with typed getter methods, `isAjax()`, `method()`, and `uri()`.
- `App/Http/Response.php` provides clean response dispatching with `text()`, `json()`, `view()`, and `redirect()` factory methods. Legacy procedural `diepage()` removed.
- `App/Http/Router.php` provides route registration (GET/POST), middleware execution pipeline, controller action execution, and clean error handling.
- `App/Helpers/TimezoneHelper.php` converted to a class with `getApplicationTimezone()`, `getClientTimezone()`, and `formatNotificationDate()`.
- `App/Middleware/CsrfMiddleware.php` provides token generation, `hash_equals` verification, and route protection.
- `App/Middleware/AuthMiddleware.php` provides session authentication verification with automatic web redirect or Ajax JSON 401 response.

Stage 3 (Avatar, Profile & UserRepository): complete
- `App/Helpers/AvatarHelper.php` provides pure, static methods for procedural Beam Avatar SVG generation.
- `App/Repositories/UserRepository.php` encapsulates PDO database queries for users and profiles with prepared statements and parameter injection.
- `App/Services/ProfileService.php` handles business validation, secure profile avatar storage, directory traversal protection, and update orchestration.
- `App/Controllers/ProfileController.php` handles profile presentation, form submission, and settings views via typed Request/Response flow.

Stage 4 (Auth): complete
- `App/Services/AuthService.php` handles password hashing, automatic re-hashing (`password_needs_rehash`), session regeneration, validation, and logout.
- `App/Controllers/AuthController.php` handles web login/registration, AJAX password change, and secure logout.
- `views/pages/auth.php` created and integrated with modern MVC parameters.

Stage 5 (Tasks & Reminders): complete
- `App/Repositories/TaskRepository.php` and `App/Repositories/ReminderRepository.php` handle all task and reminder database operations with prepared statements and transaction support.
- `App/Services/ReminderService.php` and `App/Services/TaskService.php` handle validation, reminder scheduling, transactional task creation, and status toggles.
- `App/Controllers/TaskController.php` handles task management views, AJAX task creation, completion toggles, activity view, and task deletion.
- `App/Controllers/ReminderController.php` handles reminder calculations and previews.

Stage 6 (Notifications): complete
- `App/Repositories/NotificationRepository.php` handles database queries for user notifications, status filtering, and cancellations.
- `App/Services/NotificationService.php` manages notification business rules, time calculations, and transactional updates.
- `App/Controllers/NotificationController.php` handles notification page rendering, AJAX rescheduling, and cancellations.
- Custom exceptions `NotificationNotFoundException` and `NotificationValidationException` created.

Stage 7 (Dashboard, Home & Layout): complete
- `views/layouts/dashboard.php` provides a unified, responsive dashboard master layout.
- `views/components/task-items.php` refactored into a reusable, typed component with zero accessibility warnings.
- `views/pages/home.php` and `views/pages/manage-tasks.php` made self-contained.
- `App/Controllers/HomeController.php` handles home dashboard, today/tomorrow/no-date task summaries, and badge counts.

Stage 8 (Routing & Application Kernel): complete
- `App/Application.php` encapsulates dependency injection container wiring, route loading, and request execution.
- `routes/web.php` defines all application web and API routes guarded with `AuthMiddleware`.
- `public/index.php` dispatches the request through `Application::handle($request)->send()`.
